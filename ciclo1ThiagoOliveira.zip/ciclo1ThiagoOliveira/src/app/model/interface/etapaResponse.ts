export interface EtapaResponse {
  
  etapa_id: number;
  etapa_descricao: string;
  etapa_data_inicio: string;
  etapa_data_fim: string;
  etapa_ordem: null;
  etapa_status: number;
  disciplina_id: number;
  etapa_id_pai: number;
}
