import { Component, OnInit, OnDestroy } from '@angular/core';
import { EtapaService } from '../../services/etapa.service';
import { Subject, takeUntil } from 'rxjs';
import { EtapaResponse } from '../../model/interface/etapaResponse';

@Component({
  selector: 'app-etapa',
  standalone: true,
  imports: [],
  templateUrl: './etapa.component.html',
  styleUrl: './etapa.component.css'
})
export class EtapaComponent implements OnInit, OnDestroy {

  //etapaResponse! : EtapaResponse[];

  arquivos! : any;

  constructor(private etapaService : EtapaService) { }

  private destroyer$ = new Subject<boolean>();

  ngOnInit(): void {
    this.etapaService.getEtapa(2).pipe(takeUntil(this.destroyer$)).subscribe(
      data => {
        this.arquivos = data;
      }
    );
  }

  /*
  getEtapa() : void{
    this.etapaService.getEtapa().pipe(takeUntil(this.destroyer$)).subscribe({next: (response)=> {response && (this.etapaResponse = response)
      console.log(this.etapaResponse)},
        error: (error) => console.log(error),
    })
  }
  */

  ngOnDestroy(): void {
    this.destroyer$.next(true);
    this.destroyer$.complete();
  }
}
